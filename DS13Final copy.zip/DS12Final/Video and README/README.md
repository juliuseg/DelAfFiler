Julius Grønager s204427

Press the connect button to connect and disconnect and play button to start/stop stream.

Hi, i had a bunch of struggles with trying to get the active status of the stream to work, so i can display it in the UI. I ended up by making a stream that handles that, but there must be a better way. Same with the connected/not connected. Here i solved it be sending a specific text to the stream, so it knows. But both these solitions seem clunky.

I also had a bunch of issues with getting the battery to display in the right way from the polar sensor. I have made it into a stream, but i don't think that it actually updates (when i disconnect and reconnect i get a bunch of readings of the string, that i didn't pick up using the stream while using the app. What have i done wrong here?). 

Would love some tips on how i could make this in a better way! But hey, it works nicely!