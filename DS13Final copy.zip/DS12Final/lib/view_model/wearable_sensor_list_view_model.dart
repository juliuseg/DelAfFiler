import '../model/sensor.dart';
import '../model/mock_sensor.dart';
import '../model/polar_sensor.dart';

class WearableSensorListViewModel {
  List<Sensor> get sensors => [
    MockSensor('qwerty'),
    PolarSensor('CE528D2E'),
  ];
}