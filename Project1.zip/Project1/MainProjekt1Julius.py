import importlib_resources
import numpy as np
import pandas as pd
import xlrd

file_path = 'BEAN.xls'

sheet = xlrd.open_workbook(file_path).sheet_by_index(0)

cell_value = sheet.cell_value(rowx=1, colx=1)  # Example: Read the value of the cell in the first row and column

print(cell_value)
